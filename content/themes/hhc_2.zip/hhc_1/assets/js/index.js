$(function() {
  if (window.location.pathname === '/') {
    $(".site-header").css({
      "animation": "fade-in-down 1.5s"
    });
  };

  $(".social").on("mouseenter", "a", function() {
    $(this).addClass("animated pulse");
    $(this).on("mouseleave", function() {
      $(this).removeClass("animated pulse");
    });
  });
});